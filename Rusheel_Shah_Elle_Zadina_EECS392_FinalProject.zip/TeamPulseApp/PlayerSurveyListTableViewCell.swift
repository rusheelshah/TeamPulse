//
//  PlayerSurveyListTableViewCell.swift
//  TeamPulseApp
//
//  Created by Rusheel Shah on 4/25/17.
//  Copyright © 2017 Rusheel Shah. All rights reserved.
//

import UIKit

class PlayerSurveyListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var done: UILabel!
    @IBOutlet weak var surveyLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

