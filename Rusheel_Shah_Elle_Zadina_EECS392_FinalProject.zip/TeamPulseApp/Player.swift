//
//  Player.swift
//  TeamPulseApp
//
//  Created by Rusheel Shah on 4/25/17.
//  Copyright © 2017 Rusheel Shah. All rights reserved.
//

import Foundation

class Player{
    static var playerName: String = ""
    static var playsFor: String = ""
}
