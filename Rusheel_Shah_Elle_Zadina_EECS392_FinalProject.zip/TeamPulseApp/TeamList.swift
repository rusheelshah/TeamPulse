//
//  TeamList.swift
//  TeamPulseApp
//
//  Created by Rusheel Shah on 4/23/17.
//  Copyright © 2017 Rusheel Shah. All rights reserved.
//

import Foundation


//Stores lists of teams, surveys, and names of surveys
class TeamList{
    static var teamList = [TeamID]()
    static var surveyList = [Survey]()
    static var surveyNameList = [String]()
}
