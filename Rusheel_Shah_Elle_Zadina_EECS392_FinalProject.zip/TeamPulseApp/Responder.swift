//
//  Responder.swift
//  TeamPulseApp
//
//  Created by Rusheel Shah on 4/26/17.
//  Copyright © 2017 Rusheel Shah. All rights reserved.
//

import Foundation

//Stores person that responded to specific survey on given team
struct Responder{
    static var name: String = ""
    static var survey: String = ""
    static var team: String = ""
}
