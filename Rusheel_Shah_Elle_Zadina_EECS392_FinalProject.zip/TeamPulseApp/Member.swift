//
//  Member.swift
//  TeamPulseApp
//
//  Created by Rusheel Shah on 4/22/17.
//  Copyright © 2017 Rusheel Shah. All rights reserved.
//

import Foundation

class Member{
    static var isPlayer: Bool = false
    static var isCoach: Bool = false
}
